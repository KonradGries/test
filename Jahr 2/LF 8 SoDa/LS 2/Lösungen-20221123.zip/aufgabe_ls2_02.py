""" aufgabe_ls2_02.py - Anzeige des Primärenergiebedarfs mit Hilfe von TKinter
    Name, Organisaion:          Markus Breuer, BK-GuT
    Erstellt, Letzte Änderung:  12.07.2021, 06.07.2022
    """


import sys
import tkinter as tk
from tkinter import ttk
import pandas as pd


class EnergieDaten:
    """Klasse EnergieDaten"""

    def __init__(self):
        """Konstruktor, in der die Daten aus der CSV-Datei eingelesen werden."""
        self.df = pd.read_csv("energiea.csv", sep=";")
        self.df.set_index("Energieträger", inplace=True)


    def energietraeger_holen(self):
        """Methode, um Liste der Energieträger bereitzustellen"""
        traeger_liste = list(self.df.index)
        return traeger_liste


    def kennwerte_holen(self, traeger):
        """Methode, um statistische Kennwerte für einen Energieträger bereitzustellen"""
        max_wert = self.df.loc[traeger].max()
        min_wert = self.df.loc[traeger].min()
        mittel_wert = round(self.df.loc[traeger].mean(), 2)
        return max_wert, min_wert, mittel_wert


    def jahreswerte_holen(self, traeger):
        """Methode, um Jahresverbräuche für einen Energieträger bereitzustellen"""
        jahres_liste = ["   Jahr  |  Verbrauch (PJ)"]
        jahre = list(self.df)
        for jahr in jahre:
            zeile = "  " + str(jahr) + "  |    " + str(self.df[jahr][traeger])
            jahres_liste = jahres_liste + [zeile]
        return jahres_liste


class EnergieGUI:
    """Klasse EnergieGUI"""

    def __init__(self):
        """Konstruktor, in dem das Hauptfenster aufgebaut wird"""

        self.daten = EnergieDaten()
        self.fenster = tk.Tk(className="Aufgabe_ls2_02")

        self.anlegen_hauptrahmen()
        self.anlegen_fensterelemente()
        self.setzen_elementabstaende()

        self.fenster.mainloop()


    def anlegen_hauptrahmen(self):
        """Hauptrahmen anlegen und Gesamtfenster konfogurieren"""
        self.fenster.iconbitmap("bkgut.ico")
        self.hauptrahmen = ttk.Frame(master=self.fenster, padding="20")
        self.hauptrahmen.grid(column=1, row=1, sticky="NWES")
        self.fenster.columnconfigure(1, weight=1)
        self.fenster.rowconfigure(1, weight=1)


    def anlegen_fensterelemente(self):
        """Fensterelemente (Widgets) anlegen und positionieren"""
        self.lbl_titel_1 = ttk.Label(
            master=self.hauptrahmen, text="Primärenergieverbrauch"
        )
        self.lbl_titel_1.grid(column=1, row=1, columnspan=3, sticky="SW")
        self.lbl_titel_2 = ttk.Label(master=self.hauptrahmen, text="in Deutschland")
        self.lbl_titel_2.grid(column=1, row=2, columnspan=3, sticky="NW")

        ttk.Button(
            master=self.hauptrahmen, text="Beenden", command=lambda: self.beenden()
        ).grid(column=4, row=1, rowspan=2, sticky="NSWE")

        ttk.Label(master=self.hauptrahmen, text="Auswahl Energieträger").grid(
            column=1, row=3, columnspan=2, sticky="E"
        )
        self.wert_traeger = tk.StringVar()
        self.traeger = ttk.Combobox(
            master=self.hauptrahmen, textvariable=self.wert_traeger
        )
        self.traeger.grid(column=3, row=3, sticky="WE")
        traeger_liste = self.daten.energietraeger_holen()
        self.traeger["values"] = traeger_liste
        self.traeger["state"] = ["readonly"]
        self.traeger.bind("<<ComboboxSelected>>", self.aktualisieren)

        self.wert_liste = tk.StringVar()
        self.liste = tk.Listbox(master=self.hauptrahmen, listvariable=self.wert_liste)
        self.liste.grid(column=1, row=4, rowspan=3, sticky="NSWE")
        self.srollbar = ttk.Scrollbar(
            master=self.hauptrahmen, orient=tk.VERTICAL, command=self.liste.yview
        )
        self.srollbar.grid(column=2, row=4, rowspan=3, sticky="NSE")

        ttk.Label(master=self.hauptrahmen, text="Maximaler Jahresverbrauch").grid(
            column=3, row=4, sticky="E"
        )
        self.wert_1 = tk.StringVar()
        self.zahl_1 = ttk.Entry(master=self.hauptrahmen, textvariable=self.wert_1)
        self.zahl_1.grid(column=4, row=4, sticky="WE")
        self.zahl_1["state"] = ["readonly"]

        ttk.Label(master=self.hauptrahmen, text="Minimaler Jahresverbrauch").grid(
            column=3, row=5, sticky="E"
        )
        self.wert_2 = tk.StringVar()
        self.zahl_2 = ttk.Entry(master=self.hauptrahmen, textvariable=self.wert_2)
        self.zahl_2.grid(column=4, row=5, sticky="WE")
        self.zahl_2["state"] = ["readonly"]

        ttk.Label(
            master=self.hauptrahmen, text="Durchschnittlicher Jahresverbrauch"
        ).grid(column=3, row=6, sticky="E")
        self.wert_3 = tk.StringVar()
        self.zahl_3 = ttk.Entry(master=self.hauptrahmen, textvariable=self.wert_3)
        self.zahl_3.grid(column=4, row=6, sticky="WE")
        self.zahl_3["state"] = ["readonly"]


    def setzen_elementabstaende(self):
        """Feinschliff Elementabstände"""
        for element in self.hauptrahmen.winfo_children():
            element.grid_configure(padx="10", pady="10")
        self.liste.grid_configure(padx="0", pady="10")
        self.srollbar.grid_configure(padx="0", pady="10")
        self.lbl_titel_1.grid_configure(padx="10", pady="0")
        self.lbl_titel_2.grid_configure(padx="10", pady="0")


    def beenden(self):
        """Beenden des Programms"""
        sys.exit()


    def aktualisieren(self, event):
        """Aktualisieren von Tabelle (Liste) und Kennwerten"""
        traeger = str(self.wert_traeger.get())
        max_wert, min_wert, mittel_wert = self.daten.kennwerte_holen(traeger)
        self.wert_1.set(max_wert)
        self.wert_2.set(min_wert)
        self.wert_3.set(mittel_wert)
        jahres_liste = self.daten.jahreswerte_holen(traeger)
        self.wert_liste.set(jahres_liste)


EnergieGUI()
