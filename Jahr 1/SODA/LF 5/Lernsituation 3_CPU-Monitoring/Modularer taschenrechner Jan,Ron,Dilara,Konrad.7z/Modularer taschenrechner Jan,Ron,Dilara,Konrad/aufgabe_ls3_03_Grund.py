def plus(zahl1, zahl2):     #Funktion zum Berechnen von Addition
    berechnen = zahl1 + zahl2   #Rechenoperation 
    return berechnen        #Rückgabe des Ergebnisses

def minus(zahl1, zahl2):    #Wiederholung des gleichen Prinzipes bei den restlichen Funktionen nur mit Änderung der Rechenoperation
    berechnen = zahl1 - zahl2
    return berechnen

def mal(zahl1, zahl2):
    berechnen = zahl1 * zahl2
    return berechnen

def geteilt(zahl1, zahl2):
    berechnen = zahl1 / zahl2
    return berechnen